var name = 'Loading complete, welcome valued user!';
var admin = (name);

alert(admin)
